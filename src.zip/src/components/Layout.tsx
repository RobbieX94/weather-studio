import React from 'react'
import { Link, NavLink } from 'react-router-dom'
import { btn } from './styles'

export function Layout({ children }: { children: React.ReactNode }) {
  const [theme, setTheme] = React.useState<'light' | 'dark'>('light')

  React.useEffect(() => {
    const mq = window.matchMedia('(prefers-color-scheme: dark)')
    setTheme(mq.matches ? 'dark' : 'light')
  }, [])

  React.useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme)
  }, [theme])

  const navButtonStyle = ({ isActive }: { isActive: boolean }) => ({
    padding: '10px 14px',
    borderRadius: 999,
    border: '1px solid var(--color-border)',
    background: isActive ? 'var(--color-surface)' : 'transparent',
    color: isActive ? 'var(--color-text)' : 'var(--color-text-muted)',
  })

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
      <header
        style={{
          position: 'sticky',
          top: 0,
          zIndex: 50,
          backdropFilter: 'blur(14px)',
          background: 'color-mix(in srgb, var(--color-bg) 78%, transparent)',
          borderBottom: '1px solid var(--color-divider)',
        }}
      >
        <div className="container" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', minHeight: 76, gap: 16, flexWrap: 'wrap', padding: '0 32px' }}>
          <Link to="/" style={{ display: 'flex', alignItems: 'center', gap: 14, fontWeight: 800 }}>
            <div style={{ width: 36, height: 36, borderRadius: 12, background: 'linear-gradient(135deg, var(--color-primary), #7cc7ff)', display: 'grid', placeItems: 'center', color: 'white', boxShadow: 'var(--shadow-md)' }}>
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
                <path d="M4 15.5A4.5 4.5 0 0 1 8.5 11a5.5 5.5 0 0 1 10.23 1.7A3.8 3.8 0 0 1 18.2 20H8.2A4.2 4.2 0 0 1 4 15.8Z" />
                <path d="M9 19l1.5-2.5M13 19l1.5-2.5" />
              </svg>
            </div>
            WeatherCam
          </Link>

          <nav style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center' }}>
            <NavLink to="/" end style={navButtonStyle}>Landing</NavLink>
            <NavLink to="/dashboard" style={navButtonStyle}>Dashboard</NavLink>
            <NavLink to="/map" style={navButtonStyle}>Mapa</NavLink>
            <NavLink to="/login" style={navButtonStyle}>Login</NavLink>
            <NavLink to="/contact" style={navButtonStyle}>Contacto</NavLink>
            <button
              type="button"
              onClick={() => setTheme((t) => (t === 'dark' ? 'light' : 'dark'))}
              style={{ ...btn, background: 'var(--color-surface)', color: 'var(--color-text)', border: '1px solid var(--color-border)' }}
            >
              {theme === 'dark' ? '☀ Claro' : '☾ Oscuro'}
            </button>
          </nav>
        </div>
      </header>

      <main style={{ flex: 1 }}>{children}</main>

      <footer style={{ padding: '26px 0 44px', borderTop: '1px solid var(--color-divider)', color: 'var(--color-text-muted)' }}>
        <div className="container" style={{ display: 'flex', justifyContent: 'space-between', gap: 16, flexWrap: 'wrap', padding: '0 32px' }}>
          <div>WeatherCam · prototipo funcional de interfaz para Vite/React</div>
          <div>Preparado para integrar auth, cámaras, clima y datos SQL</div>
        </div>
      </footer>
    </div>
  )
}
