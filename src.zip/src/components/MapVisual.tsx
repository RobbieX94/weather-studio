import React from 'react'

export function MapVisual({ compact = false }: { compact?: boolean }) {
  const dots: [string, string][] = [
    ['18%', '28%'],
    ['34%', '40%'],
    ['58%', '20%'],
    ['68%', '58%'],
  ]

  return (
    <div
      style={{
        position: 'relative',
        minHeight: compact ? 280 : 520,
        borderRadius: 24,
        overflow: 'hidden',
        backgroundImage:
          'linear-gradient(180deg, rgba(87,166,255,.18), rgba(87,166,255,.04)), radial-gradient(circle at 25% 30%, rgba(255,255,255,.22), transparent 18%), linear-gradient(135deg, #113051, #0a2038 54%, #102940)',
        border: '1px solid rgba(255,255,255,.1)',
      }}
    >
      <div
        style={{
          position: 'absolute',
          inset: 0,
          backgroundImage:
            'linear-gradient(rgba(255,255,255,.06) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.06) 1px, transparent 1px)',
          backgroundSize: '52px 52px',
        }}
      />

      {[
        ['10%', '22%', '36%', '22%'],
        ['48%', '28%', '24%', '16%'],
        ['52%', '58%', '28%', '18%'],
      ].map(([l, t, w, h], i) => (
        <div
          key={i}
          style={{
            position: 'absolute',
            left: l,
            top: t,
            width: w,
            height: h,
            border: '1px solid rgba(255,255,255,.18)',
            borderRadius: 999,
            background: 'rgba(255,255,255,.03)',
          }}
        />
      ))}

      {dots.map(([left, top]) => (
        <div
          key={`${left}${top}`}
          style={{
            position: 'absolute',
            left,
            top,
            width: 14,
            height: 14,
            borderRadius: '50%',
            background: '#90d0ff',
            boxShadow: '0 0 0 8px rgba(144,208,255,.12), 0 0 0 16px rgba(144,208,255,.05)',
          }}
        />
      ))}

      <div
        style={{
          position: 'absolute',
          right: 24,
          top: 22,
          minWidth: 180,
          background: 'rgba(7,17,31,.76)',
          color: '#eff6ff',
          border: '1px solid rgba(255,255,255,.08)',
          borderRadius: 18,
          padding: '14px 16px',
          backdropFilter: 'blur(18px)',
          boxShadow: 'var(--shadow-lg)',
        }}
      >
        <strong>Zona activa: Madrid Centro</strong>
        <div style={{ marginTop: 6, color: '#c8d5e6' }}>3 cámaras · lluvia 12% · nubes 74%</div>
      </div>
    </div>
  )
}
