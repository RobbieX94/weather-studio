import React from 'react'
import { btn, card, eyebrow, muted } from '../components/styles'

export function ContactPage() {
  return (
    <section style={{ padding: '24px 0 72px' }}>
      <div className="container" style={{ padding: '0 32px' }}>
        <div style={{ marginBottom: 20 }}>
          <span style={eyebrow}>Contacto</span>
          <h2 style={{ margin: '14px 0 0', fontSize: 'clamp(28px,4vw,46px)', letterSpacing: '-.04em' }}>Habla con el equipo de WeatherCam.</h2>
        </div>
        <div className="wc-contact-grid" style={{ display: 'grid', gridTemplateColumns: '.9fr 1.1fr', gap: 18, alignItems: 'start' }}>
          <aside style={{ ...card, padding: 24 }}>
            <h3 style={{ fontSize: 28, letterSpacing: '-.03em', marginTop: 0 }}>Soporte para operaciones y producto</h3>
            <p style={muted}>Página pensada para onboarding, incidencias, partnerships o integración de nuevas redes de cámaras.</p>
          </aside>

          <section style={{ ...card, padding: 24 }}>
            <h3 style={{ fontSize: 28, letterSpacing: '-.03em', marginTop: 0 }}>Escríbenos</h3>
            <form style={{ marginTop: 18, display: 'grid', gap: 16 }}>
              <label style={{ display: 'grid', gap: 8 }}>
                <span>Nombre</span>
                <input type="text" placeholder="Tu nombre" style={{ height: 48, padding: '0 14px', borderRadius: 14, border: '1px solid var(--color-border)', background: 'var(--color-surface-2)', color: 'var(--color-text)' }} />
              </label>
              <label style={{ display: 'grid', gap: 8 }}>
                <span>Email</span>
                <input type="email" placeholder="tu@email.com" style={{ height: 48, padding: '0 14px', borderRadius: 14, border: '1px solid var(--color-border)', background: 'var(--color-surface-2)', color: 'var(--color-text)' }} />
              </label>
              <label style={{ display: 'grid', gap: 8 }}>
                <span>Mensaje</span>
                <textarea rows={5} placeholder="Cuéntanos qué necesitas" style={{ padding: 14, borderRadius: 14, border: '1px solid var(--color-border)', background: 'var(--color-surface-2)', color: 'var(--color-text)', resize: 'vertical', fontFamily: 'inherit' }} />
              </label>
              <button type="button" style={{ ...btn, background: 'var(--color-primary)', color: 'white', width: 'fit-content' }}>Enviar consulta</button>
            </form>
          </section>
        </div>
      </div>
    </section>
  )
}
