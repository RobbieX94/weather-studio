import React from 'react'
import { btn, card, eyebrow, muted } from '../components/styles'

export function LoginPage() {
  return (
    <section style={{ padding: '60px 0 72px', display: 'grid', placeItems: 'center' }}>
      <div className="container" style={{ maxWidth: 1040, width: '100%', padding: '0 32px' }}>
        <div className="wc-login-grid" style={{ ...card, display: 'grid', gridTemplateColumns: '1fr 420px', overflow: 'hidden' }}>
          <div
            style={{
              padding: 36,
              background: 'radial-gradient(circle at top right, rgba(87,166,255,.22), transparent 30%), linear-gradient(180deg, #0e1d31, #0a1525 55%, #0d1b2d)',
              color: 'white',
            }}
          >
            <span style={{ ...eyebrow, background: 'rgba(255,255,255,.12)', color: 'white', border: '1px solid rgba(255,255,255,.08)' }}>Acceso seguro</span>
            <h2 style={{ fontSize: 'clamp(34px,4.5vw,58px)', lineHeight: 0.96, letterSpacing: '-.05em', margin: '18px 0' }}>
              Entra al control de clima, cámaras y decisiones.
            </h2>
            <p style={{ color: 'rgba(255,255,255,.78)', maxWidth: '44ch' }}>
              Esta pantalla está lista para conectar tu autenticación real, sesiones y permisos desde el backend ya desplegado.
            </p>
          </div>

          <div style={{ padding: 36 }}>
            <span style={eyebrow}>Login</span>
            <h2 style={{ fontSize: 38, letterSpacing: '-.04em', margin: '16px 0 10px' }}>Bienvenido de nuevo</h2>
            <p style={muted}>Inicia sesión para acceder al dashboard y a tus cámaras guardadas.</p>
            <form style={{ marginTop: 24, display: 'grid', gap: 16 }}>
              <label style={{ display: 'grid', gap: 8 }}>
                <span>Email</span>
                <input type="email" placeholder="equipo@weathercam.app" style={{ height: 48, padding: '0 14px', borderRadius: 14, border: '1px solid var(--color-border)', background: 'var(--color-surface-2)', color: 'var(--color-text)' }} />
              </label>
              <label style={{ display: 'grid', gap: 8 }}>
                <span>Contraseña</span>
                <input type="password" placeholder="••••••••" style={{ height: 48, padding: '0 14px', borderRadius: 14, border: '1px solid var(--color-border)', background: 'var(--color-surface-2)', color: 'var(--color-text)' }} />
              </label>
              <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', marginTop: 8 }}>
                <button type="button" style={{ ...btn, background: 'var(--color-primary)', color: 'white' }}>Entrar</button>
                <button type="button" style={{ ...btn, background: 'var(--color-surface)', color: 'var(--color-text)', border: '1px solid var(--color-border)' }}>Crear cuenta</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
  )
}
