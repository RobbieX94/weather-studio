export type Weather = {
  temperature: number
  feelsLike: number
  windKmh: number
  humidity: number
}

export type ForecastItem = {
  id: string
  time: string
  temperature: number
  summary: string
}

export function getCurrentWeather(): Weather {
  return { temperature: 21, feelsLike: 22, windKmh: 14, humidity: 61 }
}

export function getForecast(): ForecastItem[] {
  return [
    { id: 'fc-1', time: '18:00', temperature: 22, summary: 'Intervalos nubosos y viento suave.' },
    { id: 'fc-2', time: '19:00', temperature: 20, summary: 'Ligero descenso y cielo parcialmente despejado.' },
    { id: 'fc-3', time: '20:00', temperature: 18, summary: 'Ambiente estable con baja probabilidad de lluvia.' },
    { id: 'fc-4', time: '21:00', temperature: 17, summary: 'Noche fresca con visibilidad buena.' }
  ]
}